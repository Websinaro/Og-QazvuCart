import { and, eq, inArray, sql } from 'drizzle-orm';
import { computeDeliveryFee } from '@/src/lib/delivery';
import type { PgTransaction, PgQueryResultHKT } from 'drizzle-orm/pg-core';
import type { ExtractTablesWithRelations } from 'drizzle-orm';
import { db } from '@/src/db';
import * as schema from '@/src/db/schema';
import type { OrderStatus } from '@/src/db/schema';
import {
  orders,
  orderItems,
  orderTimeline,
  products,
  productVariants,
  productImages,
  cartItems,
  carts,
  categories,
  sellers,
  sellerOrders,
  payments,
} from '@/src/db/schema';
import { InventoryService } from './inventory';
import { AddressService } from '../addresses/addressService';
import { CartService } from '../cart/cartService';
import { CouponService } from '../coupons/couponService';
import { getDeliveryEstimate } from '@/src/lib/date';
import { estimateDeliveryDays } from '@/src/lib/shiprocket';
import { assertValidTransition, canTransition, isValidOrderStatus } from '@/src/lib/orderStateMachine';
import { priceLine, resolveCommissionRate, summarizeSellerParcel } from '@/src/lib/commission';
import { canCustomerCancel } from '@/src/lib/fulfilmentStatus';
import { PlatformSettingsService } from '../settings/platformSettingsService';
import { enqueueRefundsForClosedOrder } from '../payments/refundLedger';
import { kickPendingRefunds } from '../payments/kickRefunds';
import { OrderTrackingService } from './orderTrackingService';
import {
  confirmParcelsForOrder,
  notifySellersOfNewOrder,
  releaseCouponRedemption,
  transitionSellerOrder,
  voidParcelsForOrder,
  NotFoundError,
} from './fulfilment';

export interface CreateOrderParams {
  addressId?: number;
  shippingAddressSnapshot?: Record<string, unknown>;
  paymentMethod?: 'UPI' | 'CARD' | 'NETBANKING' | 'COD';
  couponCode?: string;
  directBuyItem?: {
    productId: number;
    variantId?: number | null;
    quantity: number;
  };
}

interface PreparedItem {
  productId: number;
  variantId: number | null;
  productName: string;
  productImage: string;
  variantName: string | null;
  unitPrice: number;
  quantity: number;
  totalPrice: number;
  estimatedDays: number;
  deliveryFee: number;
}

// A prepared item plus its seller attribution and commission snapshot.
interface PricedItem extends PreparedItem {
  sellerId: number;
  commissionBps: number;
  commissionAmount: number;
  sellerEarning: number;
}


// Both the pooled `db` instance and a `db.transaction((tx) => ...)` handle
// share the same query-builder surface (select/insert/update/delete), so
// helpers that may run either inside or outside a transaction accept this
// union rather than being locked to one concrete type.
type DbClient = typeof db | PgTransaction<PgQueryResultHKT, typeof schema, ExtractTablesWithRelations<typeof schema>>;

export class OrderService {
  /** Kept as a thin wrapper; the implementation lives in fulfilment.ts so seller flows share it. */
  private static async releaseCouponRedemption(tx: DbClient, orderId: number) {
    return releaseCouponRedemption(tx, orderId);
  }

  /**
   * Places an order inside a single PostgreSQL transaction:
   *   validate cart/products/variants -> price -> reserve inventory
   *   atomically -> create order + items + timeline -> clear cart -> COMMIT.
   * Any failure (including "out of stock" discovered at reservation time)
   * rolls the entire transaction back, so no partial order or stock
   * decrement is ever persisted.
   */
  static async createOrder(userId: number, params: CreateOrderParams) {
    const created = await db.transaction(async (tx) => {
      // 1. Resolve shipping address snapshot -------------------------------
      let addressSnapshot: Record<string, unknown> | undefined = params.shippingAddressSnapshot;
      if (!addressSnapshot && params.addressId) {
        const addr = await AddressService.getAddressById(userId, params.addressId);
        if (addr) {
          addressSnapshot = {
            fullName: addr.fullName,
            phoneNumber: addr.phoneNumber,
            houseBuilding: addr.houseBuilding,
            streetArea: addr.streetArea,
            city: addr.city,
            state: addr.state,
            postalCode: addr.postalCode,
            country: addr.country,
          };
        }
      }

      if (!addressSnapshot) {
        const addressList = await AddressService.getAddresses(userId);
        const defaultAddr = addressList.find((a) => a.isDefault) || addressList[0];
        if (defaultAddr) {
          addressSnapshot = {
            fullName: defaultAddr.fullName,
            phoneNumber: defaultAddr.phoneNumber,
            houseBuilding: defaultAddr.houseBuilding,
            streetArea: defaultAddr.streetArea,
            city: defaultAddr.city,
            state: defaultAddr.state,
            postalCode: defaultAddr.postalCode,
            country: defaultAddr.country,
          };
        } else {
          throw new Error('A delivery address is required to place an order.');
        }
      }

      // 2. Validate products / variants and price the order ----------------
      const itemsToOrder: PreparedItem[] = [];

      if (params.directBuyItem) {
        const { productId, variantId, quantity } = params.directBuyItem;

        const [prod] = await tx
          .select({
            id: products.id,
            name: products.name,
            basePrice: products.basePrice,
            discountPrice: products.discountPrice,
            stock: products.stock,
            deliveryFee: products.deliveryFee,
            estimatedDays: products.estimatedDays,
            status: products.status,
          })
          .from(products)
          .where(eq(products.id, productId))
          .limit(1);

        if (!prod || prod.status !== 'ACTIVE') throw new Error('Product not found or unavailable');

        const [primaryImage] = await tx
          .select({ imageUrl: productImages.imageUrl })
          .from(productImages)
          .where(eq(productImages.productId, prod.id))
          .orderBy(sql`${productImages.isPrimary} DESC`)
          .limit(1);

        let unitPrice = prod.discountPrice;
        let variantName: string | null = null;

        // Never trust productId/variantId independently: the variant must
        // belong to exactly this product.
        if (variantId) {
          const [v] = await tx
            .select({ variantName: productVariants.variantName, priceAdjustment: productVariants.priceAdjustment })
            .from(productVariants)
            .where(and(eq(productVariants.id, variantId), eq(productVariants.productId, productId)))
            .limit(1);
          if (!v) throw new Error('Selected variant does not belong to this product');
          variantName = v.variantName;
          unitPrice += v.priceAdjustment;
        }

        itemsToOrder.push({
          productId: prod.id,
          variantId: variantId || null,
          productName: prod.name,
          productImage: primaryImage?.imageUrl || 'https://picsum.photos/seed/prod/600/600',
          variantName,
          unitPrice,
          quantity,
          totalPrice: unitPrice * quantity,
          estimatedDays: prod.estimatedDays,
          deliveryFee: prod.deliveryFee,
        });
      } else {
        const cart = await CartService.getCart(userId);
        if (cart.items.length === 0) {
          throw new Error('Your cart is empty. Add products before checking out.');
        }

        for (const item of cart.items) {
          if (!item.inStock) {
            throw new Error(`Item ${item.productName} is out of stock.`);
          }

          // Re-validate variant ownership even for cart items, in case the
          // product's variant lineup changed between add-to-cart and checkout.
          if (item.variantId) {
            const [v] = await tx
              .select({ id: productVariants.id })
              .from(productVariants)
              .where(and(eq(productVariants.id, item.variantId), eq(productVariants.productId, item.productId)))
              .limit(1);
            if (!v) throw new Error(`A variant in your cart is no longer valid for ${item.productName}.`);
          }

          itemsToOrder.push({
            productId: item.productId,
            variantId: item.variantId,
            productName: item.productName,
            productImage: item.productImage,
            variantName: item.variantName,
            unitPrice: item.unitPrice,
            quantity: item.quantity,
            totalPrice: item.itemTotal,
            estimatedDays: item.estimatedDays,
            deliveryFee: item.deliveryFee,
          });
        }
      }

      // 2b. Seller attribution, availability + commission snapshot -----------
      // Every line is tied to the seller that owns the product. Products of a
      // seller that is not APPROVED (pending/rejected/suspended) can't be
      // bought. The commission rate is resolved once, here, and stored on the
      // line, so later rate changes never alter what a seller earned.
      const productIds = [...new Set(itemsToOrder.map((i) => i.productId))];
      const productMeta = await tx
        .select({
          id: products.id,
          sellerId: products.sellerId,
          sellerStatus: sellers.status,
          sellerCommissionBps: sellers.commissionBps,
          categoryCommissionBps: categories.commissionBps,
        })
        .from(products)
        .innerJoin(sellers, eq(products.sellerId, sellers.id))
        .innerJoin(categories, eq(products.categoryId, categories.id))
        .where(inArray(products.id, productIds));
      const metaById = new Map(productMeta.map((m) => [m.id, m]));
      const marketplaceSettings = await PlatformSettingsService.get(tx);

      const pricedItems: PricedItem[] = itemsToOrder.map((item) => {
        const meta = metaById.get(item.productId);
        if (!meta || meta.sellerStatus !== 'APPROVED') {
          throw new Error(`${item.productName} is no longer available.`);
        }
        const rate = resolveCommissionRate({
          sellerBps: meta.sellerCommissionBps,
          categoryBps: meta.categoryCommissionBps,
          platformDefaultBps: marketplaceSettings.defaultCommissionBps,
        });
        const line = priceLine({ totalPrice: item.totalPrice, rateBps: rate.bps });
        return {
          ...item,
          sellerId: meta.sellerId,
          commissionBps: rate.bps,
          commissionAmount: line.commissionAmount,
          sellerEarning: line.sellerEarning,
        };
      });

      // 3. Reserve inventory atomically -------------------------------------
      // Each reservation is a single `UPDATE ... WHERE stock >= qty RETURNING`.
      // If zero rows come back, stock was insufficient at the moment of
      // reservation (even if it looked fine a moment earlier), and we throw
      // to roll back the whole transaction - never a silent partial order.
      for (const item of itemsToOrder) {
        await InventoryService.reserve(
          tx,
          item,
          item.variantId ? `${item.productName} (${item.variantName || 'selected variant'})` : item.productName
        );
      }

      // 4. Totals & delivery estimate ----------------------------------------
      const subtotal = itemsToOrder.reduce((acc, item) => acc + item.totalPrice, 0);
      const maxEstimatedDays = Math.max(...itemsToOrder.map((i) => i.estimatedDays), 2);
      const deliveryFee = computeDeliveryFee(subtotal);

      // 4b. Coupon (optional) -------------------------------------------
      // Re-validated here, inside the same transaction that will record
      // the redemption, so a coupon can't be double-spent by two
      // concurrent checkouts racing past a standalone check-then-act.
      let couponDiscount = 0;
      let appliedCoupon: Awaited<ReturnType<typeof CouponService.validate>>['coupon'] = undefined;
      if (params.couponCode) {
        const result = await CouponService.validate(params.couponCode, userId, subtotal, tx);
        if (!result.valid) {
          throw new Error(result.message);
        }
        couponDiscount = result.discountAmount;
        appliedCoupon = result.coupon;
      }

      const total = subtotal - couponDiscount + deliveryFee;
      // Courier-quoted transit time (slowest seller parcel) + the seller's own handling days; falls back to the seller estimate.
      let etaDays = maxEstimatedDays;
      const destPin = String((addressSnapshot as Record<string, unknown> | undefined)?.postalCode ?? '');
      if (destPin) {
        const pickups = await db
          .select({ pin: schema.sellers.pickupPincode })
          .from(schema.sellers)
          .where(inArray(schema.sellers.id, [...new Set(itemsToOrder.map((i) => i.sellerId))]));
        const quotes = await Promise.all(pickups.map((p) => (p.pin ? estimateDeliveryDays(p.pin, destPin) : Promise.resolve(null))));
        const valid = quotes.filter((q): q is number => q !== null);
        if (valid.length && valid.length === pickups.length) etaDays = Math.max(...valid) + 1; // +1 day to pack & hand over
      }
      const deliveryEstimate = getDeliveryEstimate(etaDays, deliveryFee);

      const orderNumber = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
      const paymentMethod = params.paymentMethod || 'CARD';

      // COD needs no payment gateway, so it can be confirmed immediately.
      // Every other method must go through Razorpay: the order starts in
      // PENDING_PAYMENT / paymentStatus CREATED and is only ever flipped to
      // CONFIRMED/PAID by a server-verified Razorpay signature or webhook
      // (see PaymentService.verifyPayment / handleWebhook) — never by the
      // frontend simply reporting success.
      const isCod = paymentMethod === 'COD';
      const initialStatus = isCod ? 'CONFIRMED' : 'PENDING_PAYMENT';
      const initialPaymentStatus = isCod ? 'PENDING' : 'CREATED';
      // Stock was already reserved (decremented) above at creation time, so
      // an abandoned PENDING_PAYMENT reservation must expire and be
      // released back to stock — see OrderService.releaseExpiredReservations.
      const reservationExpiresAt = isCod ? null : new Date(Date.now() + 15 * 60 * 1000);

      // 5. Create order --------------------------------------------------------
      const [order] = await tx
        .insert(orders)
        .values({
          orderNumber,
          userId,
          status: initialStatus,
          subtotal,
          discount: couponDiscount,
          deliveryFee,
          total,
          shippingAddressSnapshot: addressSnapshot,
          paymentMethod,
          paymentStatus: initialPaymentStatus,
          estimatedDeliveryDate: deliveryEstimate.dateString,
          paymentReservationExpiresAt: reservationExpiresAt,
          couponCode: appliedCoupon?.code || null,
        })
        .returning({ id: orders.id });

      const orderId = order.id;

      if (appliedCoupon) {
        await CouponService.redeem(tx, appliedCoupon.id, userId, orderId, couponDiscount);
      }

      // 5b. One parcel (seller_orders row) per seller ---------------------
      const linesBySeller = new Map<number, PricedItem[]>();
      for (const item of pricedItems) {
        const list = linesBySeller.get(item.sellerId) || [];
        list.push(item);
        linesBySeller.set(item.sellerId, list);
      }
      const parcelIdBySeller = new Map<number, number>();
      for (const [sellerId, lines] of linesBySeller) {
        const totals = summarizeSellerParcel(lines.map((l) => ({ totalPrice: l.totalPrice, rateBps: l.commissionBps })));
        const [parcel] = await tx
          .insert(sellerOrders)
          .values({
            orderId,
            sellerId,
            status: initialStatus,
            subtotal: totals.subtotal,
            commissionAmount: totals.commissionAmount,
            sellerEarning: totals.sellerEarning,
          })
          .returning({ id: sellerOrders.id });
        parcelIdBySeller.set(sellerId, parcel.id);
      }

      // 6. Order items -----------------------------------------------------
      await tx.insert(orderItems).values(
        pricedItems.map((item) => ({
          orderId,
          productId: item.productId,
          variantId: item.variantId,
          productName: item.productName,
          productImage: item.productImage,
          variantName: item.variantName,
          unitPrice: item.unitPrice,
          quantity: item.quantity,
          totalPrice: item.totalPrice,
          sellerId: item.sellerId,
          sellerOrderId: parcelIdBySeller.get(item.sellerId)!,
          commissionBps: item.commissionBps,
          commissionAmount: item.commissionAmount,
          sellerEarning: item.sellerEarning,
        }))
      );

      // 7. Initial timeline --------------------------------------------------
      const timelineEvents = isCod
        ? [
            { orderId, status: 'PLACED', title: 'Order Placed', description: 'Your order was successfully submitted.', completed: true },
            { orderId, status: 'CONFIRMED', title: 'Order Confirmed', description: 'Cash on Delivery order confirmed and sent to seller for packing.', completed: true },
          ]
        : [
            { orderId, status: 'PLACED', title: 'Order Placed', description: 'Awaiting payment confirmation.', completed: true },
          ];
      await tx.insert(orderTimeline).values(timelineEvents);

      // 8. Clear cart (only for cart-based checkout) --------------------------
      if (!params.directBuyItem) {
        const [cart] = await tx.select({ id: carts.id }).from(carts).where(eq(carts.userId, userId)).limit(1);
        if (cart) {
          await tx.delete(cartItems).where(eq(cartItems.cartId, cart.id));
        }
      }

      return this.getOrderByIdWithTx(tx, userId, orderId);
    });

    // COD orders are confirmed immediately, so sellers hear about them now;
    // online orders notify sellers once payment is verified (markOrderPaid).
    if (created && params.paymentMethod === 'COD') {
      void notifySellersOfNewOrder(created.id);
    }
    return created;
  }

  /**
   * Called only by PaymentService after a Razorpay signature has been
   * verified server-side (either the browser-return verify endpoint or the
   * webhook — both funnel through here so the transition logic lives in
   * exactly one place). Idempotent: if the order is already CONFIRMED/PAID
   * this is a safe no-op, so a replayed webhook can never double-apply
   * side effects.
   */
  static async markOrderPaid(orderId: number) {
    const result = await db.transaction((tx) => this.markOrderPaidInTx(tx, orderId));
    if (!result.alreadyProcessed) {
      void notifySellersOfNewOrder(orderId);
    }
    return result;
  }

  /**
   * Transaction-scoped core of markOrderPaid, used by the payment engine so
   * the payment row and the order change commit atomically. Locks the order
   * row first (the global lock order is ORDER, then PAYMENT) and is a no-op
   * when the order is already paid.
   */
  static async markOrderPaidInTx(tx: DbClient, orderId: number) {
    const [order] = await tx
      .select({ id: orders.id, status: orders.status, paymentStatus: orders.paymentStatus })
      .from(orders)
      .where(eq(orders.id, orderId))
      .for('update');
    if (!order) throw new Error('Order not found');

    if (order.paymentStatus === 'PAID') {
      return { alreadyProcessed: true };
    }
    if (order.status !== 'PENDING_PAYMENT' && order.status !== 'PROCESSING') {
      // Never resurrect a cancelled/shipped order: the payment engine refunds instead.
      throw new Error(`Order ${orderId} is ${order.status} and cannot be marked as paid`);
    }

    await tx
      .update(orders)
      .set({ status: 'CONFIRMED', paymentStatus: 'PAID', paymentReservationExpiresAt: null, updatedAt: new Date() })
      .where(eq(orders.id, orderId));

    // Payment is verified: every seller's parcel can now be fulfilled.
    await confirmParcelsForOrder(tx, orderId);

    await tx.insert(orderTimeline).values({
      orderId,
      status: 'CONFIRMED',
      title: 'Payment Confirmed',
      description: 'Payment verified with Razorpay. Order sent to seller for packing.',
      completed: true,
    });

    return { alreadyProcessed: false };
  }

  /**
   * One payment attempt failed but the customer can still retry: the order
   * stays PENDING_PAYMENT (stock stays reserved until the reservation window
   * ends) and only its paymentStatus/timeline record the failure.
   */
  static async recordPaymentAttemptFailedInTx(tx: DbClient, orderId: number, reason?: string) {
    const [order] = await tx
      .select({ status: orders.status, paymentStatus: orders.paymentStatus })
      .from(orders)
      .where(eq(orders.id, orderId))
      .for('update');
    if (!order || order.status !== 'PENDING_PAYMENT' || order.paymentStatus === 'PAID') return;

    await tx.update(orders).set({ paymentStatus: 'FAILED', updatedAt: new Date() }).where(eq(orders.id, orderId));
    await tx.insert(orderTimeline).values({
      orderId,
      status: 'PENDING_PAYMENT',
      title: 'Payment Attempt Failed',
      description: reason ? `Payment failed: ${reason}. You can retry payment.` : 'Payment failed. You can retry payment.',
      completed: true,
    });
  }

  /**
   * Called when payment is finally given up on (retries exhausted, or the
   * reservation window expired). Releases the stock reservation taken at
   * order-creation time and marks the order CANCELLED so it doesn't sit
   * around forever as PENDING_PAYMENT. Any payment attempt still open is
   * marked CANCELLED; if money for one of them arrives later, the payment
   * engine refunds it rather than reviving the order.
   */
  static async markOrderPaymentFailed(orderId: number, reason?: string) {
    return db.transaction((tx) => this.cancelUnpaidOrderInTx(tx, orderId, reason));
  }

  static async cancelUnpaidOrderInTx(tx: DbClient, orderId: number, reason?: string) {
    const [order] = await tx
      .select({ id: orders.id, status: orders.status, paymentStatus: orders.paymentStatus })
      .from(orders)
      .where(eq(orders.id, orderId))
      .for('update');
    if (!order) throw new Error('Order not found');

    if (order.status === 'CANCELLED' || order.paymentStatus === 'PAID') {
      return { alreadyProcessed: true };
    }

    await tx
      .update(orders)
      .set({ status: 'CANCELLED', paymentStatus: 'FAILED', paymentReservationExpiresAt: null, updatedAt: new Date() })
      .where(eq(orders.id, orderId));

    await tx
      .update(payments)
      .set({ status: 'CANCELLED', updatedAt: new Date() })
      .where(and(eq(payments.orderId, orderId), inArray(payments.status, ['CREATED', 'PENDING', 'AUTHORIZED'])));

    await this.releaseCouponRedemption(tx, orderId);
    await voidParcelsForOrder(tx, orderId);

    await InventoryService.releaseOrder(tx, orderId);

    await tx.insert(orderTimeline).values({
      orderId,
      status: 'CANCELLED',
      title: 'Payment Failed',
      description: reason ? `Payment failed: ${reason}` : 'Payment failed or was cancelled.',
      completed: true,
    });

    return { alreadyProcessed: false };
  }

  /**
   * Housekeeping: PENDING_PAYMENT orders whose reservation window has
   * elapsed with no successful payment get their stock released and are
   * marked CANCELLED, the same as an explicit failure. This codebase has
   * no background worker/cron process, so nothing calls this
   * automatically today — wire it to a scheduled task (e.g. a Render Cron
   * Job hitting an authenticated internal route) if abandoned-checkout
   * cleanup matters for your deployment.
   */
  static async releaseExpiredReservations() {
    const expired = await db
      .select({ id: orders.id })
      .from(orders)
      .where(and(eq(orders.status, 'PENDING_PAYMENT'), sql`${orders.paymentReservationExpiresAt} < NOW()`));

    for (const o of expired) {
      await this.markOrderPaymentFailed(o.id, 'Payment reservation expired');
    }

    return { released: expired.length };
  }

  /** Ownership-checked fetch used by the payment routes before creating/verifying a Razorpay order. */
  static async getOrderForPayment(userId: number, orderId: number) {
    const [order] = await db
      .select()
      .from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.userId, userId)))
      .limit(1);
    return order || null;
  }

  static async getUserOrders(userId: number, statusFilter?: string) {
    const conditions = [eq(orders.userId, userId)];
    if (statusFilter && statusFilter !== 'ALL' && isValidOrderStatus(statusFilter.toUpperCase())) {
      conditions.push(eq(orders.status, statusFilter.toUpperCase()));
    }

    const rows = await db
      .select()
      .from(orders)
      .where(and(...conditions))
      .orderBy(sql`${orders.id} DESC`);

    const result = [];
    for (const o of rows) {
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
      const itemCount = items.length;
      const first = items[0];

      result.push({
        id: o.id,
        orderNumber: o.orderNumber,
        status: o.status,
        subtotal: o.subtotal,
        discount: o.discount,
        couponCode: o.couponCode,
        deliveryFee: o.deliveryFee,
        total: o.total,
        paymentMethod: o.paymentMethod,
        paymentStatus: o.paymentStatus,
        estimatedDeliveryDate: o.estimatedDeliveryDate,
        createdAt: o.createdAt.toISOString(),
        itemCount,
        summaryName: itemCount > 1 ? `${first?.productName} + ${itemCount - 1} more item(s)` : first?.productName,
        primaryImage: first?.productImage || 'https://picsum.photos/seed/prod/600/600',
      });
    }

    return result;
  }

  static async getOrderById(userId: number, orderId: number | string) {
    return this.getOrderByIdWithTx(db, userId, orderId);
  }

  private static async getOrderByIdWithTx(txOrDb: DbClient, userId: number, orderId: number | string) {
    const isNum = !isNaN(Number(orderId));

    const [order] = await txOrDb
      .select()
      .from(orders)
      .where(
        isNum
          ? and(eq(orders.userId, userId), sql`(${orders.id} = ${Number(orderId)} OR ${orders.orderNumber} = ${String(orderId)})`)
          : and(eq(orders.userId, userId), eq(orders.orderNumber, String(orderId)))
      )
      .limit(1);

    if (!order) return null;

    const items = await txOrDb
      .select({
        id: orderItems.id,
        productId: orderItems.productId,
        variantId: orderItems.variantId,
        productName: orderItems.productName,
        productImage: orderItems.productImage,
        variantName: orderItems.variantName,
        unitPrice: orderItems.unitPrice,
        quantity: orderItems.quantity,
        totalPrice: orderItems.totalPrice,
        productSlug: products.slug,
        sellerOrderId: orderItems.sellerOrderId,
      })
      .from(orderItems)
      .leftJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, order.id));

    // Each seller ships their own parcel; the customer still has one order.
    const parcelRows = await txOrDb
      .select({
        id: sellerOrders.id,
        status: sellerOrders.status,
        carrier: sellerOrders.carrier,
        trackingNumber: sellerOrders.trackingNumber,
        updatedAt: sellerOrders.updatedAt,
        sellerName: sellers.storeName,
        sellerSlug: sellers.slug,
      })
      .from(sellerOrders)
      .innerJoin(sellers, eq(sellerOrders.sellerId, sellers.id))
      .where(eq(sellerOrders.orderId, order.id))
      .orderBy(sellerOrders.id);

    const timeline = await txOrDb
      .select()
      .from(orderTimeline)
      .where(eq(orderTimeline.orderId, order.id))
      .orderBy(sql`${orderTimeline.id} ASC`);

    const allStages = [
      { key: 'PLACED', title: 'Order Placed', desc: 'Order confirmed and verified' },
      { key: 'CONFIRMED', title: 'Payment Confirmed', desc: order.paymentMethod === 'COD' ? 'Cash on Delivery confirmed' : 'Payment received successfully' },
      { key: 'PACKED', title: 'Packed', desc: 'Seller packed the parcel' },
      { key: 'SHIPPED', title: 'Shipped', desc: 'Handed over to delivery carrier' },
      { key: 'OUT_FOR_DELIVERY', title: 'Out for Delivery', desc: 'Courier out for delivery today' },
      { key: 'DELIVERED', title: 'Delivered', desc: 'Successfully delivered' },
    ];
    const timelineMap = new Map(timeline.map((t) => [t.status, t]));

    const fullStepper = allStages.map((stage, idx) => {
      const existing = timelineMap.get(stage.key);
      return {
        step: idx + 1,
        status: stage.key,
        title: stage.title,
        description: existing ? existing.description : stage.desc,
        completed: Boolean(existing),
        occurredAt: existing ? existing.occurredAt.toISOString() : null,
      };
    });

    return {
      id: order.id,
      orderNumber: order.orderNumber,
      userId: order.userId,
      status: order.status,
      subtotal: order.subtotal,
      discount: order.discount,
      couponCode: order.couponCode,
      deliveryFee: order.deliveryFee,
      total: order.total,
      shippingAddress: order.shippingAddressSnapshot,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      estimatedDeliveryDate: order.estimatedDeliveryDate,
      createdAt: order.createdAt.toISOString(),
      items: items.map((i) => ({
        id: i.id,
        productId: i.productId,
        productSlug: i.productSlug,
        productName: i.productName,
        productImage: i.productImage,
        variantName: i.variantName,
        unitPrice: i.unitPrice,
        quantity: i.quantity,
        totalPrice: i.totalPrice,
      })),
      timeline: fullStepper,
      ...(await OrderTrackingService.getExtras(order.id, order.status)),
      canCancel: canCustomerCancel(parcelRows.map((p) => p.status)) && !['CANCELLED','RETURNED','DELIVERED'].includes(order.status),
      parcels: parcelRows.map((p) => ({
        id: p.id,
        sellerName: p.sellerName,
        sellerSlug: p.sellerSlug,
        status: p.status,
        carrier: p.carrier,
        trackingNumber: p.trackingNumber,
        updatedAt: p.updatedAt.toISOString(),
        itemIds: items.filter((i) => i.sellerOrderId === p.id).map((i) => i.id),
      })),
    };
  }

  /** Customer-initiated cancellation. Only valid pre-dispatch, per the order state machine. */
  static async cancelOrder(userId: number, orderId: number) {
    const result = await db.transaction(async (tx) => {
      const [order] = await tx
        .select({ id: orders.id, status: orders.status })
        .from(orders)
        .where(and(eq(orders.id, orderId), eq(orders.userId, userId)))
        .for('update');

      if (!order) throw new Error('Order not found');

      assertValidTransition(order.status, 'CANCELLED');

      // The order status is the *least advanced* parcel, so also make sure no
      // seller has already shipped their part before cancelling everything.
      const parcels = await tx.select({ status: sellerOrders.status }).from(sellerOrders).where(eq(sellerOrders.orderId, orderId));
      if (!canCustomerCancel(parcels.map((p) => p.status))) {
        throw new Error('Part of this order has already been shipped, so it can no longer be cancelled.');
      }

      await tx.update(orders).set({ status: 'CANCELLED', updatedAt: new Date() }).where(eq(orders.id, orderId));

      await this.releaseCouponRedemption(tx, orderId);
      await voidParcelsForOrder(tx, orderId);

      await InventoryService.releaseOrder(tx, orderId);

      await tx.insert(orderTimeline).values({
        orderId,
        status: 'CANCELLED',
        title: 'Order Cancelled',
        description: 'Customer requested cancellation before dispatch.',
        completed: true,
      });

      // Money already collected goes back automatically: the refund intent is
      // committed with the cancellation; the gateway call follows post-commit.
      await enqueueRefundsForClosedOrder(tx, orderId, 'cancel');

      return this.getOrderByIdWithTx(tx, userId, orderId);
    });
    kickPendingRefunds();
    void OrderTrackingService.notifyProgress(orderId, 'CANCELLED');
    return result;
  }

  /**
   * Admin status change for a whole order. The change is applied to every
   * parcel that can legally make the move (parcels already further along, or
   * in a terminal state, are skipped); if no parcel can, the state machine's
   * error is surfaced. The customer-facing status is then re-derived.
   */
  static async adminUpdateStatus(orderId: number, nextStatus: string, adminUserId = 0) {
    return db.transaction(async (tx) => {
      const [order] = await tx.select({ id: orders.id }).from(orders).where(eq(orders.id, orderId)).limit(1);
      if (!order) throw new Error('Order not found');
      if (!isValidOrderStatus(nextStatus)) throw new Error(`"${nextStatus}" is not a valid order status.`);

      const parcels = await tx
        .select({ id: sellerOrders.id, status: sellerOrders.status })
        .from(sellerOrders)
        .where(eq(sellerOrders.orderId, orderId))
        .orderBy(sellerOrders.id);
      if (parcels.length === 0) throw new Error('This order has no seller parcels to update.');

      const movable = parcels.filter((p) => canTransition(p.status as OrderStatus, nextStatus));
      if (movable.length === 0) {
        // Re-run the check on the first parcel to produce the precise error message.
        assertValidTransition(parcels[0].status, nextStatus);
      }

      for (const p of movable) {
        await transitionSellerOrder(tx, p.id, nextStatus, { type: 'ADMIN', userId: adminUserId });
      }
      return true;
    }).then((r) => { kickPendingRefunds(); void OrderTrackingService.notifyProgress(orderId, nextStatus); return r; });
  }

  /** Admin status change for a single seller's parcel. */
  static async adminUpdateParcelStatus(sellerOrderId: number, nextStatus: string, adminUserId: number) {
    return db.transaction(async (tx) => {
      return transitionSellerOrder(tx, sellerOrderId, nextStatus, { type: 'ADMIN', userId: adminUserId });
    }).then((r) => { kickPendingRefunds(); void OrderTrackingService.notifyProgress(r.orderId, nextStatus, sellerOrderId); return r; });
  }
}

export { NotFoundError };
