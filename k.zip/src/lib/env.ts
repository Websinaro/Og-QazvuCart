/**
 * Centralized environment configuration.
 *
 * Hard rule: secrets have NO hardcoded fallback values. If a required secret
 * is missing, the process throws at startup (fail fast) instead of silently
 * running with a well-known, guessable default.
 */

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value || value.trim().length === 0) {
    throw new Error(
      `${name} is required. Set it in your environment (see .env.example) before starting the server.`
    );
  }
  return value;
}

export const env = {
  get DATABASE_URL() {
    return requireEnv('DATABASE_URL');
  },
  get JWT_SECRET() {
    return requireEnv('JWT_SECRET');
  },
  get JWT_REFRESH_SECRET() {
    return requireEnv('JWT_REFRESH_SECRET');
  },
};

/**
 * Razorpay TEST MODE credentials. Lazy getters so importing this module
 * never fails just because payments aren't configured yet in local dev —
 * only routes that actually create/verify a payment will throw, and only
 * at the moment they're invoked. The key SECRET and WEBHOOK secret must
 * never reach the browser; only `keyId` is ever sent to the client (see
 * app/api/payments/razorpay/create-order/route.ts).
 */
export const razorpayEnv = {
  get keyId() {
    return requireEnv('RAZORPAY_KEY_ID');
  },
  get keySecret() {
    return requireEnv('RAZORPAY_KEY_SECRET');
  },
  get webhookSecret() {
    return requireEnv('RAZORPAY_WEBHOOK_SECRET');
  },
};

/**
 * Shared secret for the scheduled maintenance endpoint
 * (POST /api/internal/payments/maintenance). Lazy for the same reason as
 * razorpayEnv: only that route needs it.
 */
export const maintenanceEnv = {
  get cronSecret() {
    return requireEnv('CRON_SECRET');
  },
};

/**
 * Firebase Admin SDK credentials — used server-side only, to send Web Push
 * notifications via FCM (see src/lib/firebaseAdmin.ts). Lazy getters, same
 * rationale as razorpayEnv: importing this module must never fail just
 * because push notifications aren't configured yet; only the send path
 * throws, and only when actually invoked. PRIVATE_KEY commonly arrives
 * from the hosting provider's env UI with literal "\n" sequences instead
 * of real newlines, so it's unescaped here rather than at every call site.
 */
export const firebaseAdminEnv = {
  get projectId() {
    return requireEnv('FIREBASE_PROJECT_ID');
  },
  get clientEmail() {
    return requireEnv('FIREBASE_CLIENT_EMAIL');
  },
  get privateKey() {
    return requireEnv('FIREBASE_PRIVATE_KEY').replace(/\\n/g, '\n');
  },
};

export const config = {
  jwtExpiresIn: '15m',
  jwtRefreshExpiresIn: '30d',
  cookieName: 'marketplace_token',
  refreshCookieName: 'marketplace_refresh_token',
  appName: 'QazvuCart Multi-Vendor Marketplace',
  defaultCurrency: 'INR',
  defaultDeliveryFee: 40,
  freeDeliveryThreshold: 999,
} as const;

/**
 * One-time admin bootstrap (CLI only — see src/scripts/create-admin.ts).
 *
 * These variables are read ONLY by `npm run admin:bootstrap`. The running
 * web application never reads them, so they cannot be used to log in or to
 * gain admin through registration/login. Remove them after bootstrapping.
 */
export const bootstrap = {
  get adminEmail() {
    return requireEnv('ADMIN_BOOTSTRAP_EMAIL');
  },
  get adminPassword() {
    return requireEnv('ADMIN_BOOTSTRAP_PASSWORD');
  },
  get adminUsername(): string | undefined {
    const v = process.env.ADMIN_BOOTSTRAP_USERNAME?.trim();
    return v ? v : undefined;
  },
};
